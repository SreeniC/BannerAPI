﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MongoDB.Driver;
using System.Configuration;
using MongoDB.Driver.Builders;

namespace BannerAPI.Models
{

    public class BannerRepository : IBannerRepository
    {

        MongoServer mongoServer = null;
        MongoDatabase mongoDatabase = null;
        MongoCollection mongoCollection = null;

        #region TestData
        Banner[] banners = new Banner[]{
         new Banner{Id =1, Html="<html><head>First Banner</head><body></body></html>", Created=DateTime.Now,Modified=DateTime.Now},
         new Banner{Id =2, Html="<html><head>Second Banner</head><body></body></html>", Created=DateTime.Now,Modified=DateTime.Now},
         new Banner{Id =3, Html="<html><head>Third Banner</head><body></body></html>", Created=DateTime.Now,Modified=DateTime.Now}
        };
        #endregion

        List<Banner> bannerList = new List<Banner>();

        string connectionString = ConfigurationManager.AppSettings["MongoDBConectionString"];
        //var client = new MongoClient(connectionString);
        //var server = client.GetServer();
        string databaseName = ConfigurationManager.AppSettings["MongoDBDatabaseName"];
        string tableName = ConfigurationManager.AppSettings["Banner_Tbl"];

        public BannerRepository()
        {
            try
            {
                mongoServer = MongoServer.Create(connectionString);
                mongoServer.Connect();

                mongoDatabase = mongoServer.GetDatabase(databaseName);
                mongoCollection = mongoDatabase.GetCollection<Banner>(tableName);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public IEnumerable<Banner> GetAll()
        {
            #region GetFromDB
            if (Convert.ToInt32(mongoCollection.Count()) > 0)
            {
                bannerList.Clear();
                var bannerCollection = mongoCollection.FindAs(typeof(Banner), Query.NE("html", "null"));

                if (bannerCollection.Count() > 0)
                {
                    foreach (Banner banner in bannerCollection)
                    {
                        bannerList.Add(banner);
                    }
                }
            }
            else
            {
                #region Add some test data since our DB is empty
                mongoCollection.RemoveAll();
                foreach (Banner banner in banners)
                {
                    bannerList.Add(banner);

                    //save data to collection

                    Add(banner);
                }
                #endregion
            }

            #endregion

            var results = bannerList.AsQueryable();

            return results;
        }

       public IEnumerable<Banner> GetByHtml(string html)
        { 
            bannerList.Clear();

            var bannerCollection = mongoCollection.FindAs(typeof(Banner), Query.EQ("html", html));

            if (bannerCollection.Count() > 0)
            {
                foreach (Banner banner in bannerCollection)
                {
                    bannerList.Add(banner);
                }
            }

            return bannerList.AsQueryable();
        }

        public Banner Get(int bannerId)
        {
            Banner banner = (Banner)mongoCollection.FindOneAs(typeof(Banner), Query.EQ("_id", bannerId));
            return banner;
        }

        public Banner Add(Banner banner)
        {
            if (banner != null)
            {
                mongoCollection.Save(banner);
            }
            return banner;
        }

        public bool Delete(int bannerId)
        {
            mongoCollection.Remove(Query.EQ("_id", bannerId));
            return true;
        }

        public bool Update(Banner banner)
        {
            UpdateBuilder updateBuilder = MongoDB.Driver.Builders.Update.Set("Html", banner.Html)
                                                                        .Set("Created", banner.Created)
                                                                        .Set("Modified", banner.Modified);
            mongoCollection.Update(Query.EQ("_id", banner.Id), updateBuilder);
            return true;
        }
    }
}