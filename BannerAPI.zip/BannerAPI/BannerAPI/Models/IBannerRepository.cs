﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BannerAPI.Models
{
    interface IBannerRepository
    {
        IEnumerable<Banner> GetAll();
        IEnumerable<Banner> GetByHtml(string html);
        Banner Get(int bannerId);
        Banner Add(Banner banner);
        bool Delete(int bannerId);
        bool Update(Banner banner);
    }
}