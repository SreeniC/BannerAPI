﻿using BannerAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BannerAPI.Controllers
{
    public class BannerController : ApiController
    {
        static readonly IBannerRepository repository = new BannerRepository();

        // GET api/<controller>
        public IEnumerable<Banner> GetAll()
        {
            return repository.GetAll();
        }

        public IEnumerable<Banner> GetByHtml(string html)
        {
            return repository.GetByHtml(html);
        }

        // GET api/<controller>/5
        public Banner Get(int bannerId)
        {
            //return "value";
            Banner banner = repository.Get(bannerId);
            if (banner == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return banner;
        }

        // POST api/<controller>
        public Banner Post([FromBody]Banner banner)
        {
           return banner = repository.Add(banner);
        }

        // PUT api/<controller>/5
        public void Put(int bannerId, [FromBody]Banner banner)
        {
            banner.Id = bannerId;
            if (!repository.Update(banner))
	        {
                throw new HttpResponseException(HttpStatusCode.NotFound);
	        }
        }

        // DELETE api/<controller>/5
        public void Delete(int bannerId)
        {
            if (repository.Get(bannerId) == null)
                throw new HttpResponseException(HttpStatusCode.NotFound);
            else
                repository.Delete(bannerId);
        }
    }
}